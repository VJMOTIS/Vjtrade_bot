
# main.py
from src.ui.telegram_ui import launch_telegram_ui

if __name__ == "__main__":
    launch_telegram_ui("7962371909:AAH6mbS5OKvv_pDfB_sNS08bKi7MMD-OPwA")

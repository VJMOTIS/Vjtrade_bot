
# Trading limits
MAX_DAILY_LOSS = 50.0  # Maximum allowed daily loss
MIN_DAILY_PROFIT = 100.0  # Target daily profit

# Trading hours (24h format)
TRADING_START_HOUR = 9
TRADING_END_HOUR = 17
BREAK_START_HOUR = 12
BREAK_END_HOUR = 13

# Strategy parameters
STRATEGY_VERSION = "1.0"
DEFAULT_TIMEFRAME = 60  # 1 minute candles
DEFAULT_SYMBOL = "EURUSD"

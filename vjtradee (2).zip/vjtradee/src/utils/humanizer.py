import random
import time

def simulate_mouse_movement():
    steps = random.randint(5, 10)
    for _ in range(steps):
        time.sleep(random.uniform(0.05, 0.2))  # pause like hovering
        print("🖱️ Moving mouse slightly...")

def scroll_chart_randomly():
    direction = random.choice(["left", "right"])
    print(f"🖱️ Scrolling chart {direction}...")

def random_tab_switch():
    tab = random.choice(["Indicators", "Volume", "Login Tab", "Zoom"])
    print(f"🧭 Switching to tab: {tab}")
    time.sleep(random.uniform(0.5, 1.5))

def simulate_human_behavior():
    """Simulate human-like delays and behavior"""
    print("🧠 Simulating human behavior...")
    simulate_mouse_movement()
    scroll_chart_randomly()
    random_tab_switch()
    time.sleep(random.uniform(1.5, 3.0)) # added delay from edited code
    print("✅ Human-like behavior complete.")

def random_delay():
    """Add random delay between actions"""
    time.sleep(random.uniform(0.5, 2.0))uniform(0.5, 2.0))

import time
from datetime import datetime
from src.core.auth_manager import get_client, get_mode
from src.monitoring.timing_scheduler import is_within_trading_hours, is_break_time
from src.strategies.strategy_engine import get_final_signal
from src.utils.humanizer import simulate_human_behavior
from src.utils.logger import log_info, log_error
from src.monitoring.status_manager import update_status, bot_status
from src.strategies.strategy_engine import get_final_signal
from src.strategies.smart_profit import check_profit_target, check_loss_limit
from src.utils.humanizer import simulate_human_behavior
from src.monitoring.timing_scheduler import is_within_trading_hours, is_break_time
from src.utils.logger import log_info, log_error

def start_trading():
    bot_status["trading_active"] = True
    update_status(True)
    log_info("🟢 Trading started")

    while bot_status["trading_active"]:
        try:
            if not is_within_trading_hours():
                log_info("⏳ Outside trading hours. Sleeping...")
                time.sleep(120)
                continue

            if is_break_time():
                log_info("😴 On break. Sleeping...")
                time.sleep(180)
                continue

            client = get_client()
            if client:
                candles = client.get_candles("EURUSD", 60, 20)

                if check_profit_target() or check_loss_limit():
                    log_info("🎯 Target hit or loss limit reached. Stopping...")
                    stop_trading()
                    break

                signal = get_final_signal(candles)
                if signal:
                    simulate_human_behavior()
                    result = client.place_trade("EURUSD", signal, 1, 60)
                    update_status(True, str(result))
                    log_info(f"Trade placed: {result}")
                else:
                    log_info("⚠️ No valid signal found. Waiting...")

            time.sleep(70)

        except Exception as e:
            log_error(f"❌ Trading Error: {e}")
            time.sleep(30)

def stop_trading():
    bot_status["trading_active"] = False
    update_status(False)
    log_info("Trading stopped")

def get_last_trade_info():
    return "No trades yet" if not bot_status.get("last_result") else str(bot_status["last_result"])

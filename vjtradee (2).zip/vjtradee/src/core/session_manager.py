
# Session management
current_session = {
    "user": None,
    "mode": "demo",  # or "live"
    "active": False
}

def save_session(user, mode="demo"):
    current_session["user"] = user
    current_session["mode"] = mode
    current_session["active"] = True

def clear_session():
    current_session["user"] = None
    current_session["mode"] = "demo"
    current_session["active"] = False

def get_current_session():
    return current_session

def get_current_mode():
    return current_session["mode"]

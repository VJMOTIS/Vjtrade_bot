from datetime import datetime

client = None
logged_in = False
current_mode = "DEMO"
current_email = None

def login(email, password, mode="DEMO"):
    global client, logged_in, current_mode, current_email
    try:
        # Simplified login logic
        logged_in = True
        current_mode = mode.upper()
        current_email = email
        return True
    except Exception as e:
        print(f"Login error: {str(e)}")
        return False

def logout():
    global client, logged_in, current_email
    client = None
    logged_in = False
    current_email = None

def is_logged_in():
    return logged_in

def get_client():
    return client

def get_mode():
    return current_mode

def get_current_user():
    return current_email if current_email else "Not logged in"

def switch_mode():
    global current_mode
    current_mode = "REAL" if current_mode == "DEMO" else "DEMO"
    session = get_current_session()
    if session:
        login(session["email"], session["password"], current_mode)
    return f"Switched to *{current_mode}* mode"

async def get_balance():
    return 1000.0  # Placeholder balance

from src.core.session_manager import save_session, clear_session, get_current_session
# market_filter.py

import random
from datetime import datetime

def get_market_volume():
    # Dummy placeholder for volume info
    return random.randint(1, 100)

def detect_market_pattern(candles):
    # Example: pattern recognition logic
    closes = [c['close'] for c in candles]
    if len(closes) < 5:
        return "unknown"

    if closes[-1] > closes[-2] > closes[-3]:
        return "uptrend"
    elif closes[-1] < closes[-2] < closes[-3]:
        return "downtrend"
    else:
        return "sideways"

def ai_confidence_score(signal, pattern, volume):
    score = 0
    if pattern == "uptrend" and signal == "call":
        score += 40
    elif pattern == "downtrend" and signal == "put":
        score += 40
    else:
        score -= 10

    if 30 < volume < 80:
        score += 30
    else:
        score -= 10

    time_now = datetime.now().hour
    if 6 <= time_now <= 10 or 19 <= time_now <= 22:
        score += 30  # Smart trading hours
    else:
        score -= 10

    return max(0, min(100, score))

def is_signal_valid(signal, candles):
    pattern = detect_market_pattern(candles)
    volume = get_market_volume()
    confidence = ai_confidence_score(signal, pattern, volume)

    return confidence >= 70  # Min threshold

def get_current_pair():
    return "EURUSD"  # Default trading pair

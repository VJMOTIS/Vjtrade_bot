import json
import os

ACCOUNT_FILE = "accounts.json"

def save_account(name, email, password, mode):
    data = load_all_accounts()
    data[name] = {
        "email": email,
        "password": password,
        "mode": mode
    }
    with open(ACCOUNT_FILE, "w") as f:
        json.dump(data, f)

def load_all_accounts():
    if os.path.exists(ACCOUNT_FILE):
        with open(ACCOUNT_FILE, "r") as f:
            return json.load(f)
    return {}

def get_account(name):
    accounts = load_all_accounts()
    return accounts.get(name)

def list_accounts():
    return list(load_all_accounts().keys())

def delete_account(name):
    data = load_all_accounts()
    if name in data:
        del data[name]
        with open(ACCOUNT_FILE, "w") as f:
            json.dump(data, f)

# ✅ Missing functions added here

def switch_account(name):
    account = get_account(name)
    if account:
        with open("current_account.json", "w") as f:
            json.dump({"current": name}, f)
        return True
    return False

def get_account_list():
    return list_accounts()

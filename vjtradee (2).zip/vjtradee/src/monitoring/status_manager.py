from datetime import datetime
from src.core.session_manager import get_current_mode
from src.strategies.strategy_engine import get_current_strategy

# Initialize bot status
bot_status = {
    "trading_active": False,
    "last_trade": None
}

def update_status(is_active, trade_info=None):
    bot_status["trading_active"] = is_active
    if trade_info:
        bot_status["last_trade"] = trade_info

def get_bot_status():
    mode = get_current_mode()
    strategy = get_current_strategy()
    running = "✅ ACTIVE" if bot_status["trading_active"] else "🛑 STOPPED"
    last_time = bot_status["last_trade"] or "--"

    return (
        f"⚙️ **Bot Status Summary**\n"
        f"🔁 Status: {running}\n"
        f"🧠 Strategy: `{strategy}`\n"
        f"🎯 Mode: {mode}\n"
        f"🕒 Last Trade: `{last_time}`"
    )

def get_last_result():
    return bot_status["last_trade"] or "No trade yet"

def get_last_trade_info():
    return f"🔄 Last Trade Result: {get_last_result()}"
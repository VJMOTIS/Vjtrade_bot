# pnl_reporter.py

import datetime
from utils.config import REPORT_INTERVAL
from utils.logger import log_info

trade_history = []

# ✅ This is the expected import in other files
def log_trade_result(result):
    """
    This is a wrapper for backward compatibility.
    Expected to be called with a dict:
    {'profit': 0.9, 'result': 'win', 'pair': 'EURUSD'}
    """
    profit = result.get("profit", 0)
    outcome = result.get("result", "unknown")
    pair = result.get("pair", "unknown")
    timestamp = result.get("time", datetime.datetime.now())
    record_trade(profit, outcome, pair, timestamp)

def record_trade(profit, result, pair, timestamp=None):
    if not timestamp:
        timestamp = datetime.datetime.now()
    trade_history.append({
        "profit": profit,
        "result": result,
        "pair": pair,
        "time": timestamp
    })

def get_last_trade_summary():
    if not trade_history:
        return "❌ No trades recorded yet."
    last = trade_history[-1]
    return f"""🟢 **Last Trade Info**
🔹 Result: {last['result']}
🔹 Profit: {'🟢 +' if last['profit'] > 0 else '🔴 '}{last['profit']}$  
🔹 Pair: {last['pair']}
🕒 Time: {last['time'].strftime('%I:%M %p')} IST"""ftime('%I:%M %p')} IST"""

def get_today_pnl():
    today = datetime.datetime.now().date()
    total = sum(t["profit"] for t in trade_history if t["time"].date() == today)
    wins = sum(1 for t in trade_history if t["result"] == "win")
    losses = sum(1 for t in trade_history if t["result"] == "loss")
    return f"""📊 **Today's PnL Summary**
🟢 Total PnL: {'🟢 +' if total > 0 else '🔴 '}{total}$
✅ Wins: {wins} | ❌ Losses: {losses}
📅 Date: {today.strftime('%d %b %Y')}"""

def get_trade_count_last_interval():
    now = datetime.datetime.now()
    interval_start = now - datetime.timedelta(minutes=REPORT_INTERVAL)
    count = sum(1 for t in trade_history if t["time"] >= interval_start)
    return count

def get_today_report():
    today_pnl = get_today_pnl()
    return f"""📊 *Today's Trading Report*
💰 Total PnL: ${today_pnl}
📅 Date: {datetime.datetime.now().strftime('%d %b %Y')}"""
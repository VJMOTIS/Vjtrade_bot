from datetime import datetime
from src.utils.config import (
    TRADING_START_HOUR,
    TRADING_END_HOUR,
    BREAK_START_HOUR,
    BREAK_END_HOUR
)

import datetime
import random
import time

# Trading window (IST 6:00 AM – 10:00 PM)
START_HOUR = 6
END_HOUR = 22

def ist_now():
    return datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30)

def is_within_trading_hours():
    current_hour = datetime.now().hour
    return TRADING_START_HOUR <= current_hour < TRADING_END_HOUR

def get_next_break_time():
    now = ist_now()
    break_in_min = random.randint(25, 40)
    return now + datetime.timedelta(minutes=break_in_min)

def take_random_break():
    break_duration = random.randint(120, 240)  # 2 to 4 mins
    print(f"😴 Taking random break for {break_duration} seconds...")
    time.sleep(break_duration)

def should_take_break():
    # 20% chance every cycle
    return random.random() < 0.2

def is_break_time():
    current_hour = datetime.now().hour
    return BREAK_START_HOUR <= current_hour < BREAK_END_HOUR_HOUR
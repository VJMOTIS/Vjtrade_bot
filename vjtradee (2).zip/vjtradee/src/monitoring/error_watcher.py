# error_watcher.py

import time
from system_control import restart_browser, restart_loop
from utils.logger import log_error

def safe_recover(reason="Unknown"):
    log_error(f"🔁 Triggering safe recovery: {reason}")

    try:
        # Try restarting browser/session first
        restart_browser()
        time.sleep(5)
        restart_loop()
        time.sleep(5)
        log_error("✅ Recovery attempt completed.")
    except Exception as e:
        log_error(f"Recovery failed: {str(e)}")

from datetime import datetime
from src.utils.config import MAX_DAILY_LOSS, MIN_DAILY_PROFIT
import os

pnl_file = "pnl_log.txt"

def log_trade_pnl(pnl):
    with open(pnl_file, "a") as f:
        f.write(f"{datetime.now().date()},{pnl}\n")

def get_today_pnl():
    if not os.path.exists(pnl_file):
        return 0
    today = str(datetime.now().date())
    total = 0
    with open(pnl_file, "r") as f:
        for line in f:
            date_str, pnl = line.strip().split(",")
            if date_str == today:
                total += float(pnl)
    return round(total, 2)

def is_profit_target_hit():
    pnl = get_today_pnl()
    return pnl >= MIN_DAILY_PROFIT

def is_loss_limit_hit():
    pnl = get_today_pnl()
    return pnl <= -MAX_DAILY_LOSS

def should_continue_trading():
    if is_profit_target_hit():
        print("✅ Profit target achieved. Stopping.")
        return False
    if is_loss_limit_hit():
        print("❌ Max loss reached. Stopping.")
        return False
    return True

def get_capital_plan():
    return f"""📌 *Capital Management Plan*
• Min Daily Profit: ${MIN_DAILY_PROFIT}
• Max Daily Loss: ${MAX_DAILY_LOSS}
• Today's PnL: ${get_today_pnl()}"""

# ✅ Aliases for backward compatibility
check_profit_target = is_profit_target_hit
check_loss_limit = is_loss_limit_hit

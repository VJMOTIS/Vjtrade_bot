# strategy_engine.py

def rsi(candles, period=14):
    gains, losses = [], []
    for i in range(1, period + 1):
        diff = candles[-i]['close'] - candles[-i - 1]['close']
        if diff >= 0:
            gains.append(diff)
        else:
            losses.append(abs(diff))
    avg_gain = sum(gains) / period if gains else 0
    avg_loss = sum(losses) / period if losses else 1  #Handle case with no losses
    rs = avg_gain / avg_loss if avg_loss >0 else 100 #handle division by zero
    return 100 - (100 / (1 + rs)) if rs >=0 else 0 #handle negative rs values

def ema(candles, period=14):
    k = 2 / (period + 1)
    if len(candles) < period:
        return None #Handle insufficient data
    ema_val = candles[-period]['close']
    for i in range(-period + 1, 0):
        ema_val = candles[i]['close'] * k + ema_val * (1 - k)
    return ema_val

def macd(candles):
    ema12 = ema(candles, 12)
    ema26 = ema(candles, 26)
    if ema12 is None or ema26 is None:
        return None #Handle cases where EMA calculations fail due to insufficient data.
    return ema12 - ema26

def detect_candle_pattern(candles):
    if len(candles) < 2:
        return None #Handle insufficient data
    last = candles[-1]
    second_last = candles[-2]
    if second_last['close'] < second_last['open'] and last['close'] > last['open']:
        return "bullish"
    elif second_last['close'] > second_last['open'] and last['close'] < last['open']:
        return "bearish"
    return None

def strategy_main(candles):
    """Main trading strategy implementation using RSI, MACD, EMA, and candle patterns."""
    if not candles or len(candles) < 20:
        return None

    _rsi = rsi(candles)
    _macd = macd(candles)
    _ema = ema(candles, 20) #Using a 20 period EMA for consistency
    pattern = detect_candle_pattern(candles)

    if _rsi is not None and _macd is not None and _ema is not None and pattern: #check for None values from calculations
        if _rsi < 30 and _macd > 0 and candles[-1]['close'] > _ema and pattern == "bullish":
            return "call"
        elif _rsi > 70 and _macd < 0 and candles[-1]['close'] < _ema and pattern == "bearish":
            return "put"
    return None

def backup_strategy(candles):
    if len(candles) < 5:
        return None #Handle insufficient data
    closes = [c['close'] for c in candles[-5:]]
    avg = sum(closes) / len(closes)
    last = candles[-1]['close']

    if last > avg:
        return "put"
    elif last < avg:
        return "call"
    return None

def get_final_signal(candles):
    """Get the final trading signal based on all indicators"""
    signal = strategy_main(candles)
    if signal:
        return signal
    return backup_strategy(candles)

def get_current_strategy():
    """Return current active strategy name"""
    return "Smart Profit v1.0"
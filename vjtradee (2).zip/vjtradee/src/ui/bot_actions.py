from telegram import ReplyKeyboardRemove
from src.core.session_manager import save_session, clear_session, get_current_session
from src.core.auth_manager import login, logout, switch_mode, get_balance

user_login_state = {}

async def handle_button_action(update, context):
    query = update.callback_query
    action = query.data
    chat_id = update.effective_chat.id

    if action == "login":
        user_login_state[chat_id] = {"step": "email"}
        await context.bot.send_message(chat_id=chat_id, text="📧 Enter your Quotex email:")
        return

    if action == "logout":
        logout()
        await context.bot.send_message(chat_id=chat_id, text="🔓 Logged out successfully.")
        return

    if action == "switch":
        msg = switch_mode()
        await context.bot.send_message(chat_id=chat_id, text=msg, parse_mode='Markdown')
        return

    if action == "balance":
        balance = await get_balance()
        await context.bot.send_message(chat_id=chat_id, text=f"💰 Current Balance: *${balance}*", parse_mode='Markdown')
        return

    await context.bot.send_message(chat_id=chat_id, text=f"🛠️ Action `{action}` received. (Not implemented)")

async def handle_login_input(update, context):
    chat_id = update.effective_chat.id
    user_state = user_login_state.get(chat_id)

    if not user_state:
        return

    text = update.message.text
    
    if user_state["step"] == "email":
        user_state["email"] = text
        user_state["step"] = "password"
        await context.bot.send_message(chat_id=chat_id, text="🔑 Enter your password:")
    elif user_state["step"] == "password":
        email = user_state["email"]
        password = text
        
        success = login(email, password)
        if success:
            await context.bot.send_message(chat_id=chat_id, text="✅ Logged in successfully!")
            save_session(email)
        else:
            await context.bot.send_message(chat_id=chat_id, text="❌ Login failed. Please check credentials.")
        user_login_state.pop(chat_id, None)
        await context.bot.send_message(
            chat_id=chat_id,
            text="Login process completed",
            reply_markup=ReplyKeyboardRemove()
        )e.text.strip()

    if user_state["step"] == "email":
        user_state["email"] = text
        user_state["step"] = "password"
        await context.bot.send_message(chat_id=chat_id, text="🔑 Enter your Quotex password:")
    elif user_state["step"] == "password":
        email = user_state["email"]
        password = text
        success = login(email, password)
        if success:
            await context.bot.send_message(chat_id=chat_id, text="✅ Logged in successfully!")
            user_login_state.pop(chat_id, None) #Added this line to handle the incomplete change
            await context.bot.send_message(
                chat_id=chat_id,
                text="Login process completed",
                reply_markup=ReplyKeyboardRemove()
            )
        else:
            await context.bot.send_message(chat_id=chat_id, text="❌ Login failed. Please check credentials.")
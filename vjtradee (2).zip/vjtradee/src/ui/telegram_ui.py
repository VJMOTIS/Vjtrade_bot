
import os
import asyncio
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, ReplyKeyboardMarkup
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters
from src.ui.bot_actions import handle_button_action, handle_login_input
from src.core.auth_manager import login, logout, is_logged_in, get_mode, switch_mode, get_current_user, get_balance
from src.core.trading_core import start_trading, stop_trading, get_last_trade_info
from src.strategies.smart_profit import get_today_pnl, get_capital_plan
from src.monitoring.status_manager import get_bot_status

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == 'start':
        start_trading()
        await query.edit_message_text("🟢 Bot started!")
    elif query.data == 'stop':
        stop_trading()
        await query.edit_message_text("⛔ Bot stopped!")
    elif query.data == 'balance':
        balance = await get_balance()
        await query.edit_message_text(f"💰 Balance: ${balance:.2f}")
    elif query.data == 'switch':
        result = switch_mode()
        await query.edit_message_text(result)
    elif query.data == 'status':
        status = get_bot_status()
        await query.edit_message_text(status, parse_mode='Markdown')
    elif query.data == 'logout':
        logout()
        await query.edit_message_text("🔓 Logged out successfully!")
    elif query.data == 'today_pnl':
        pnl = get_today_pnl()
        await query.edit_message_text(f"📊 Today's PnL: ${pnl}")
    elif query.data == 'capital_plan':
        plan = get_capital_plan()
        await query.edit_message_text(plan, parse_mode='Markdown')

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_logged_in():
        credentials = update.message.text.split(':')
        if len(credentials) == 2:
            email, password = credentials
            if login(email.strip(), password.strip()):
                await update.message.reply_text("🔐 Login successful!", reply_markup=InlineKeyboardMarkup([build_main_keyboard()]))
            else:
                await update.message.reply_text("❌ Login failed! Try again.")
        else:
            await update.message.reply_text("⚠️ Please send credentials in format: email:password")

def build_main_keyboard():
    keyboard = [
        [InlineKeyboardButton("🟢 Start", callback_data='start'), InlineKeyboardButton("⛔ Stop", callback_data='stop')],
        [InlineKeyboardButton("💳 Balance", callback_data='balance'), InlineKeyboardButton("📊 Today PnL", callback_data='today_pnl')],
        [InlineKeyboardButton("⚙️ Status", callback_data='status'), InlineKeyboardButton("♻️ Switch Mode", callback_data='switch')],
        [InlineKeyboardButton("🔓 Logout", callback_data='logout'), InlineKeyboardButton("📌 Capital Plan", callback_data='capital_plan')]
    ]
    return keyboard

def launch_telegram_ui(token):
    app = Application.builder().token(token).build()
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    print("🤖 Bot started! Send your credentials in format: email:password")
    app.run_polling()
